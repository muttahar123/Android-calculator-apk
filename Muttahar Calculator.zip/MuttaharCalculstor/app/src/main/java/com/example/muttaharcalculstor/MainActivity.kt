package com.example.muttaharcalculstor

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var zero: Button
    private lateinit var one: Button
    private lateinit var two: Button
    private lateinit var three: Button
    private lateinit var four: Button
    private lateinit var five: Button
    private lateinit var six: Button
    private lateinit var seven: Button
    private lateinit var eight: Button
    private lateinit var nine: Button
    private lateinit var add: Button
    private lateinit var sub: Button
    private lateinit var mul: Button
    private lateinit var div: Button
    private lateinit var equal: Button
    private lateinit var clear: Button
    private lateinit var info: TextView
    private lateinit var result: TextView

    private val ADDITION = '+'
    private val SUBTRACTION = '-'
    private val MULTIPLICATION = '*'
    private val DIVISION = '/'
    private var val1 = Double.NaN
    private var val2 = 0.0
    private var ACTION: Char? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupUIViews()

        // Set button click listeners
        zero.setOnClickListener { appendToInfo("0") }
        one.setOnClickListener { appendToInfo("1") }
        two.setOnClickListener { appendToInfo("2") }
        three.setOnClickListener { appendToInfo("3") }
        four.setOnClickListener { appendToInfo("4") }
        five.setOnClickListener { appendToInfo("5") }
        six.setOnClickListener { appendToInfo("6") }
        seven.setOnClickListener { appendToInfo("7") }
        eight.setOnClickListener { appendToInfo("8") }
        nine.setOnClickListener { appendToInfo("9") }

        sub.setOnClickListener { performOperation(SUBTRACTION) }
        add.setOnClickListener { performOperation(ADDITION) }
        mul.setOnClickListener { performOperation(MULTIPLICATION) }
        div.setOnClickListener { performOperation(DIVISION) }

        equal.setOnClickListener {
            compute()
            info.text = "" // Clear input after computation
            ACTION = null // Reset ACTION
        }

        clear.setOnClickListener {
            clearAll()
        }
    }

    private fun setupUIViews() {
        zero = findViewById(R.id.btn0)
        one = findViewById(R.id.btn1)
        two = findViewById(R.id.btn2)
        three = findViewById(R.id.btn3)
        four = findViewById(R.id.btn4)
        five = findViewById(R.id.btn5)
        six = findViewById(R.id.btn6)
        seven = findViewById(R.id.btn7)
        eight = findViewById(R.id.btn8)
        nine = findViewById(R.id.btn9)
        add = findViewById(R.id.btnadd)
        sub = findViewById(R.id.btnsub)
        mul = findViewById(R.id.btnmul)
        div = findViewById(R.id.btndivide)
        equal = findViewById(R.id.btnequal)
        info = findViewById(R.id.tvControl)
        result = findViewById(R.id.tvResult)
        clear = findViewById(R.id.btnclear)
    }

    private fun appendToInfo(value: String) {
        info.text = info.text.toString() + value
    }

    private fun performOperation(action: Char) {
        compute()
        ACTION = action
        val1 = if (!java.lang.Double.isNaN(val1)) val1 else info.text.toString().toDouble()
        info.text = ""
    }

    private fun compute() {
        if (!java.lang.Double.isNaN(val1)) {
            val2 = info.text.toString().toDouble()
            when (ACTION) {
                ADDITION -> val1 += val2
                SUBTRACTION -> val1 -= val2
                MULTIPLICATION -> val1 *= val2
                DIVISION -> {
                    if (val2 != 0.0) {
                        val1 /= val2
                    } else {
                        result.text = "Error: Division by Zero"
                        clearAll()
                        return
                    }
                }
            }
            result.text = val1.toString() // Display the result
        } else {
            val1 = info.text.toString().toDouble()
        }
    }

    private fun clearAll() {
        val1 = Double.NaN
        val2 = 0.0
        info.text = ""
        result.text = ""
        ACTION = null
    }
}
